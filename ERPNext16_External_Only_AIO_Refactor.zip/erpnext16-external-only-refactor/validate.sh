#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CF="$ROOT/erpnext16/single-aio/Containerfile"
EP="$ROOT/erpnext16/single-aio/rootfs/usr/local/bin/entrypoint.sh"
WF="$ROOT/.github/workflows/erpnext16-single-container-aio.yml"

bash -n "$EP"
bash -n "$ROOT/erpnext16/scripts/fetch-ashan-custom-app.sh"
bash -n "$ROOT/erpnext16/scripts/build-local.sh"
bash -n "$ROOT/unraid/migrate-current-container.sh"
bash -n "$ROOT/apply-to-docker-repo.sh"

if grep -Fq 'AIO_MODE' "$EP"; then
  echo 'ERROR: AIO_MODE remains in entrypoint' >&2
  exit 1
fi

if grep -Fq 'bench build --app ashan_cn_procurement' "$CF"; then
  echo 'ERROR: second Ashan frontend build remains' >&2
  exit 1
fi

# Inspect executable package-install lines only; comments are ignored.
if grep -E '^[[:space:]]+(mariadb-server|mariadb-client|redis-server|redis-tools)([[:space:]\\]|$)' "$CF"; then
  echo 'ERROR: bundled DB/Redis package remains' >&2
  exit 1
fi

grep -Fq "printf 'frappe\\nerpnext\\nashan_cn_procurement\\n' > sites/apps.txt" "$CF"
grep -Fq "printf 'frappe\\nerpnext\\nashan_cn_procurement\\n' > \"\$SITES/apps.txt\"" "$EP"
grep -Fq 'ASHAN_REPO_REF: main' "$WF"
grep -Fq 'MANIFEST="erpnext16/apps.json"' "$WF"
grep -Fq '!custom-apps/ashan_cn_procurement/**' "$ROOT/erpnext16/.dockerignore"

echo 'Static validation PASS'
