#!/usr/bin/env bash
set -Eeuo pipefail

C="${1:-erpnext16}"
SITES="${2:-/mnt/cache/appdata/erpnext16/sites}"
APPS="$SITES/apps.txt"

mkdir -p "$SITES"

STAMP="$(date +%Y%m%d_%H%M%S)"
if [[ -f "$APPS" ]]; then
  cp "$APPS" "$APPS.bak-$STAMP"
  echo "Backup: $APPS.bak-$STAMP"
fi

printf 'frappe\nerpnext\nashan_cn_procurement\n' > "$APPS"

echo "Repaired host apps.txt:"
cat "$APPS"

if docker inspect "$C" >/dev/null 2>&1; then
  docker cp "$APPS" "$C:/opt/sites-skel/apps.txt" || true
  docker restart "$C"
  echo
  echo "Recent container logs:"
  docker logs --tail 160 "$C"
else
  echo "Container $C not found; host apps.txt was still repaired."
fi
