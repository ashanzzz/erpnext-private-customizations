#!/usr/bin/env bash
set -Eeuo pipefail

C="${C:-erpnext16}"
IMAGE="${IMAGE:-ghcr.io/ashanzzz/erpnext16:latest}"

docker inspect "$C" >/dev/null 2>&1 || {
  echo "ERROR: current container not found: $C" >&2
  exit 1
}

get_env() {
  docker inspect "$C" \
    --format '{{range .Config.Env}}{{println .}}{{end}}' |
    sed -n "s/^$1=//p" |
    head -n1
}

SITE_NAME="$(get_env SITE_NAME)"
ADMIN_PASSWORD="$(get_env ADMIN_PASSWORD)"
DB_TYPE="$(get_env FRAPPE_DB_TYPE)"
DB_HOST="$(get_env FRAPPE_DB_HOST)"
DB_PORT="$(get_env FRAPPE_DB_PORT)"
DB_NAME="$(get_env FRAPPE_DB_NAME)"
DB_USER="$(get_env FRAPPE_DB_USER)"
DB_PASSWORD="$(get_env FRAPPE_DB_PASSWORD)"
REDIS_CACHE="$(get_env FRAPPE_REDIS_CACHE)"
REDIS_QUEUE="$(get_env FRAPPE_REDIS_QUEUE)"
REDIS_SOCKETIO="$(get_env FRAPPE_REDIS_SOCKETIO)"
TZ_VALUE="$(get_env TZ)"

SITE_NAME="${SITE_NAME:-site1.local}"
DB_TYPE="${DB_TYPE:-mariadb}"
DB_PORT="${DB_PORT:-3306}"
TZ_VALUE="${TZ_VALUE:-Asia/Shanghai}"

HOST_PORT="$(
  docker inspect "$C" \
    --format '{{with index .NetworkSettings.Ports "8080/tcp"}}{{(index . 0).HostPort}}{{end}}'
)"
HOST_PORT="${HOST_PORT:-6888}"

SITES_PATH="$(
  docker inspect "$C" \
    --format '{{range .Mounts}}{{if eq .Destination "/home/frappe/frappe-bench/sites"}}{{.Source}}{{end}}{{end}}'
)"
SITES_PATH="${SITES_PATH:-/mnt/cache/appdata/erpnext16/sites}"

for name in DB_HOST DB_NAME DB_USER DB_PASSWORD REDIS_CACHE REDIS_QUEUE REDIS_SOCKETIO; do
  [[ -n "${!name:-}" ]] || {
    echo "ERROR: missing current value: $name" >&2
    exit 2
  }
done

STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$SITES_PATH/.migration-backups"

docker inspect "$C" \
  > "$SITES_PATH/.migration-backups/docker-inspect-$STAMP.json"

if [[ -f "$SITES_PATH/apps.txt" ]]; then
  cp "$SITES_PATH/apps.txt" \
    "$SITES_PATH/.migration-backups/apps.txt-$STAMP"
fi

# Repair the current corruption before the new image ever starts.
printf 'frappe\nerpnext\nashan_cn_procurement\n' > "$SITES_PATH/apps.txt"

echo "Pulling: $IMAGE"
docker pull "$IMAGE"

echo "Replacing container..."
docker rm -f "$C"

docker run -d \
  --name "$C" \
  --restart unless-stopped \
  --network bridge \
  -p "${HOST_PORT}:8080" \
  -v "${SITES_PATH}:/home/frappe/frappe-bench/sites" \
  -e "SITE_NAME=${SITE_NAME}" \
  -e "ADMIN_PASSWORD=${ADMIN_PASSWORD}" \
  -e "FRAPPE_DB_TYPE=${DB_TYPE}" \
  -e "FRAPPE_DB_HOST=${DB_HOST}" \
  -e "FRAPPE_DB_PORT=${DB_PORT}" \
  -e "FRAPPE_DB_NAME=${DB_NAME}" \
  -e "FRAPPE_DB_USER=${DB_USER}" \
  -e "FRAPPE_DB_PASSWORD=${DB_PASSWORD}" \
  -e "FRAPPE_REDIS_CACHE=${REDIS_CACHE}" \
  -e "FRAPPE_REDIS_QUEUE=${REDIS_QUEUE}" \
  -e "FRAPPE_REDIS_SOCKETIO=${REDIS_SOCKETIO}" \
  -e "TZ=${TZ_VALUE}" \
  "$IMAGE"

echo
echo "Container recreated."
echo "Follow logs with:"
echo "  docker logs -f $C"
