#!/usr/bin/env bash
set -Eeuo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-}"

[[ -n "$REPO" ]] || {
  echo "Usage: $0 /path/to/ashanzzz-docker" >&2
  exit 2
}

REPO="$(cd "$REPO" && pwd)"
[[ -d "$REPO/.git" ]] || {
  echo "ERROR: not a Git repository: $REPO" >&2
  exit 3
}

install -D -m 0644 \
  "$BUNDLE/.github/workflows/erpnext16-single-container-aio.yml" \
  "$REPO/.github/workflows/erpnext16-single-container-aio.yml"

install -D -m 0644 \
  "$BUNDLE/erpnext16/single-aio/Containerfile" \
  "$REPO/erpnext16/single-aio/Containerfile"

install -D -m 0755 \
  "$BUNDLE/erpnext16/single-aio/rootfs/usr/local/bin/entrypoint.sh" \
  "$REPO/erpnext16/single-aio/rootfs/usr/local/bin/entrypoint.sh"

install -D -m 0755 \
  "$BUNDLE/erpnext16/single-aio/rootfs/usr/local/bin/aio-healthcheck.sh" \
  "$REPO/erpnext16/single-aio/rootfs/usr/local/bin/aio-healthcheck.sh"

install -D -m 0644 \
  "$BUNDLE/erpnext16/single-aio/rootfs/etc/supervisor/supervisord.conf" \
  "$REPO/erpnext16/single-aio/rootfs/etc/supervisor/supervisord.conf"

install -D -m 0644 \
  "$BUNDLE/erpnext16/single-aio/rootfs/etc/supervisor/conf.d/20-erpnext.conf" \
  "$REPO/erpnext16/single-aio/rootfs/etc/supervisor/conf.d/20-erpnext.conf"

install -D -m 0755 \
  "$BUNDLE/erpnext16/scripts/fetch-ashan-custom-app.sh" \
  "$REPO/erpnext16/scripts/fetch-ashan-custom-app.sh"

install -D -m 0644 \
  "$BUNDLE/erpnext16/.dockerignore" \
  "$REPO/erpnext16/.dockerignore"

install -D -m 0644 \
  "$BUNDLE/erpnext16/apps.json" \
  "$REPO/erpnext16/apps.json"

install -D -m 0755 \
  "$BUNDLE/erpnext16/scripts/build-local.sh" \
  "$REPO/erpnext16/scripts/build-local.sh"

install -D -m 0644 \
  "$BUNDLE/erpnext16/README.md" \
  "$REPO/erpnext16/README.md"

install -D -m 0644 \
  "$BUNDLE/erpnext16/single-aio/README.md" \
  "$REPO/erpnext16/single-aio/README.md"

install -D -m 0644 \
  "$BUNDLE/erpnext16/custom-apps/README.md" \
  "$REPO/erpnext16/custom-apps/README.md"

install -D -m 0644 \
  "$BUNDLE/erpnext16/docs/external-only-aio.md" \
  "$REPO/erpnext16/docs/external-only-aio.md"

# Explicitly remove only files that belong to the old bundled DB/Redis path.
rm -f "$REPO/erpnext16/single-aio/rootfs/etc/supervisor/conf.d/00-mariadb.conf"
rm -f "$REPO/erpnext16/single-aio/rootfs/etc/supervisor/conf.d/00-redis.conf"
rm -f "$REPO/erpnext16/single-aio/rootfs/usr/local/bin/run-mariadb.sh"
rm -f "$REPO/erpnext16/single-aio/rootfs/usr/local/bin/run-redis.sh"
rm -f "$REPO/erpnext16/single-aio/rootfs/etc/mysql/mariadb.conf.d/99-erpnext.cnf"

# Remove obsolete parallel build/deployment routes so there is only one AIO path.
rm -f "$REPO/erpnext16/run.sh"
rm -f "$REPO/erpnext16/overrides/compose.mariadb.yaml"
rm -f "$REPO/erpnext16/overrides/compose.redis.yaml"
rm -f "$REPO/erpnext16/overrides/compose.noproxy.yaml"
rm -f "$REPO/erpnext16/image/Containerfile"
rm -f "$REPO/erpnext16/image/build.sh"
rm -f "$REPO/erpnext16/image/README.md"
rm -f "$REPO/erpnext16/image/apps.json"
rm -f "$REPO/erpnext16/image/apps.json.example"
rm -f "$REPO/erpnext16/scripts/fetch-private-customizations.sh"
rm -f "$REPO/erpnext16/docs/asset-integrity-aio.md"

echo "External-only ERPNext16 refactor applied."
echo
git -C "$REPO" status --short
