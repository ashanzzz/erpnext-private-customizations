# ERPNext16 External-Only AIO refactor

This package is an overlay for the current `ashanzzz/docker` repository.

## Final architecture

```text
Unraid
  |
  +-- erpnext16 container
  |     +-- nginx :8080
  |     +-- gunicorn :8000
  |     +-- socketio :9000
  |     +-- worker
  |     +-- scheduler
  |
  +-- external MariaDB
  |
  +-- external Redis
```

There is no internal MariaDB/Redis mode.

## Image contents

```text
Frappe 16
ERPNext 16
ashan_cn_procurement
nginx
supervisor
```

Ashan remains in its own repository:

```text
ashanzzz/erpnext-private-customizations
```

GitHub Actions vendors `main` into the Docker build context and bakes it into
the final ERPNext image.

## Fixed failure modes

### 1. `erpnextashan_cn_procurement`

The runtime no longer appends to `sites/apps.txt`.

The file is written deterministically:

```text
frappe
erpnext
ashan_cn_procurement
```

before any Bench command and again after migration.

### 2. Missing Ashan code

The image build fails if Ashan cannot be fetched or imported.

### 3. Yarn exit 143

The image does not run a second:

```text
bench build --app ashan_cn_procurement
```

Ashan currently uses direct files under `public/`; those are exposed through:

```text
sites/assets/ashan_cn_procurement
```

### 4. Internal/external branching

Removed entirely.

The following old runtime units are deleted:

```text
00-mariadb.conf
00-redis.conf
run-mariadb.sh
run-redis.sh
99-erpnext.cnf
```

The image no longer installs MariaDB or Redis packages.

### 5. Supervisor startup order

Old:

```text
start supervisord
-> configure DB
-> install apps
-> migrate
-> start programs
```

New:

```text
validate external configuration
-> repair apps.txt
-> refresh image assets
-> verify MariaDB/Redis TCP endpoints
-> create/check site
-> install missing apps
-> migrate
-> nginx -t
-> exec supervisord
```

No web/worker process starts before migration succeeds.

## Applying to the Docker repository

```bash
chmod +x apply-to-docker-repo.sh
./apply-to-docker-repo.sh /path/to/docker
```

Then:

```bash
cd /path/to/docker
git diff --check
git diff
git add .
git commit -m "refactor(erpnext16): external-only AIO runtime"
git push
```

## GitHub Actions

The Docker workflow continues to publish:

```text
ghcr.io/ashanzzz/erpnext16:latest
ghcr.io/ashanzzz/erpnext16:aio
ghcr.io/ashanzzz/erpnext16:v16.x.y-aio
ghcr.io/ashanzzz/erpnext16:sha-xxxxxxxxxxxx-aio
```

The published image is smoke-tested to ensure:

- Frappe imports
- ERPNext imports
- Ashan imports
- apps.txt is exactly correct
- internal MariaDB/Redis supervisor units are absent

## Optional Ashan -> Docker automatic rebuild

Copy:

```text
ashan-repo/.github/workflows/rebuild-erpnext16.yml
```

into the Ashan repository and configure a `DOCKER_REPO_PAT` secret that can
dispatch workflows in `ashanzzz/docker`.

Then every push to Ashan `main` rebuilds the ERPNext image automatically.

## Unraid

A new external-only XML example is included:

```text
unraid/my-erpnext16-external-only.xml
```

After the new GHCR image is successfully built, the migration script can
recreate the current container while preserving the existing sites bind and
external DB/Redis environment:

```bash
bash unraid/migrate-current-container.sh
```

It first backs up the current Docker inspect and `apps.txt`, then repairs
`apps.txt`, pulls `latest`, and recreates the container without the old
`AIO_MODE` or internal service settings.
