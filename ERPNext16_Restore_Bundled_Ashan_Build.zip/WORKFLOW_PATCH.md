在 `.github/workflows/erpnext16-single-container-aio.yml` 的 checkout 后、Install jq 前加入：

```yaml
      - name: Fetch Ashan ERPNext custom app
        shell: bash
        env:
          ASHAN_REPO_TOKEN: ${{ secrets.ASHAN_REPO_TOKEN }}
          ASHAN_REPO_REF: main
        run: |
          set -euo pipefail
          chmod +x erpnext16/scripts/fetch-ashan-custom-app.sh
          bash erpnext16/scripts/fetch-ashan-custom-app.sh
```

当前 Ashan 仓库是公开仓库，因此 ASHAN_REPO_TOKEN 可以为空。
