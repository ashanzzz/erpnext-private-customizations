修复 `ensure_site_apps()`：

旧逻辑把 `bench --site ... list-apps` 的换行全部删除：

```bash
| tr -d '\n'
```

删除这一段，保留多行结果，再逐行判断 App 名称。

这会修复反复出现：

```text
Installing missing app on site1.local: erpnext
App erpnext already installed
```
