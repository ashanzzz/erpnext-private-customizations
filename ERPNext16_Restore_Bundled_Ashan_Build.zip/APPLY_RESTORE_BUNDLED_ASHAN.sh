#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-}"
if [[ -z "$REPO" ]]; then
  echo "Usage: $0 /path/to/ashanzzz-docker" >&2
  exit 2
fi
if [[ ! -d "$REPO/.git" ]]; then
  echo "Not a Git repository: $REPO" >&2
  exit 3
fi

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$REPO/erpnext16/scripts"
cp -f "$SRC/erpnext16/scripts/fetch-ashan-custom-app.sh" "$REPO/erpnext16/scripts/fetch-ashan-custom-app.sh"
chmod +x "$REPO/erpnext16/scripts/fetch-ashan-custom-app.sh"

WORKFLOW="$REPO/.github/workflows/erpnext16-single-container-aio.yml"
python3 - "$WORKFLOW" <<'PYCODE'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
marker = "      - name: Install jq\n"
step = (
    "      - name: Fetch Ashan ERPNext custom app\n"
    "        shell: bash\n"
    "        env:\n"
    "          ASHAN_REPO_TOKEN: ${{ secrets.ASHAN_REPO_TOKEN }}\n"
    "          ASHAN_REPO_REF: main\n"
    "        run: |\n"
    "          set -euo pipefail\n"
    "          chmod +x erpnext16/scripts/fetch-ashan-custom-app.sh\n"
    "          bash erpnext16/scripts/fetch-ashan-custom-app.sh\n\n"
)
if "Fetch Ashan ERPNext custom app" not in s:
    if marker not in s:
        raise SystemExit("Could not find workflow insertion marker: Install jq")
    s = s.replace(marker, step + marker, 1)
p.write_text(s)
PYCODE

ENTRY="$REPO/erpnext16/single-aio/rootfs/usr/local/bin/entrypoint.sh"
python3 - "$ENTRY" <<'PYCODE'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
s = s.replace("| tr -d '\\n' || true", "|| true")
p.write_text(s)
PYCODE

chmod +x "$ENTRY"

echo "Applied minimal restore."
echo "Review:"
echo "  git -C \"$REPO\" diff --check"
echo "  git -C \"$REPO\" diff"
echo "  git -C \"$REPO\" status --short"
echo
echo "Then:"
echo "  git -C \"$REPO\" add ."
echo "  git -C \"$REPO\" commit -m 'fix(erpnext16): bundle Ashan app from independent repo during AIO build'"
echo "  git -C \"$REPO\" push"
