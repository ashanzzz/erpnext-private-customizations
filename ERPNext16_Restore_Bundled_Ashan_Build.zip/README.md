# ERPNext16：恢复构建时打入 Ashan

推荐结构：

```text
ashanzzz/erpnext-private-customizations
= Ashan 源码主仓库
        ↓ 构建前 clone
ashanzzz/docker/erpnext16/custom-apps/ashan_cn_procurement
= 临时 build staging
        ↓ 当前 Containerfile
ghcr.io/ashanzzz/erpnext16:latest
= Frappe + ERPNext + Ashan 完整镜像
```

## 为什么这是更合适的方案

- Ashan 仍然是独立 Git 仓库。
- AIO 构建时获取 Ashan 最新源码。
- 最终 Docker 镜像包含 Site 已安装的 App 代码。
- `bench migrate` 不会因为缺少 `ashan_cn_procurement` 失败。
- Unraid 不需要额外挂载 App。
- 回滚 Docker tag 时，ERPNext 与 Ashan 版本一起回滚，部署更一致。

## 为什么不直接 git revert

历史提交：

```text
c47f8a1ad4f7455758429c59ad24c17e096aded4
feat(erpnext16): remove private custom sync from aio build
```

确实删除了构建前同步机制。

但是旧脚本假设 Ashan 仓库有：

```text
erpnext16/custom-apps/
```

当前 Ashan 仓库已经不是这个结构。现在仓库根目录本身就是 Frappe App root：

```text
pyproject.toml
ashan_cn_procurement/
...
```

所以应该恢复“机制”，但使用新版同步脚本。

## 应用

```bash
chmod +x APPLY_RESTORE_BUNDLED_ASHAN.sh
./APPLY_RESTORE_BUNDLED_ASHAN.sh /path/to/ashanzzz-docker
```

检查：

```bash
git -C /path/to/ashanzzz-docker diff --check
git -C /path/to/ashanzzz-docker diff
git -C /path/to/ashanzzz-docker status --short
```

提交：

```bash
git -C /path/to/ashanzzz-docker add .
git -C /path/to/ashanzzz-docker commit   -m "fix(erpnext16): bundle Ashan app from independent repo during AIO build"
git -C /path/to/ashanzzz-docker push
```

push 后当前 Actions 会自动构建新的 `ghcr.io/ashanzzz/erpnext16:latest`。

## Ashan push 自动触发 AIO

可选文件：

```text
ashan-repo/.github/workflows/trigger-erpnext16-aio.yml
```

需要在 Ashan 仓库配置：

```text
DOCKER_REPO_PAT
```

否则 Ashan 更新后手动运行 Docker 仓库的 workflow 即可。
