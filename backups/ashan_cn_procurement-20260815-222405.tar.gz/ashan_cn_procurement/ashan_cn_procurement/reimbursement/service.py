"""Server-side reimbursement domain services."""

from __future__ import annotations

from collections.abc import Iterable

import frappe
from frappe import _
from frappe.utils import flt


ACTIVE_RESERVATION_STATUSES = ("Draft", "Submitted")


def normalize_names(values: str | Iterable[str] | None) -> list[str]:
    """Return safe, de-duplicated document names from RPC input."""
    if isinstance(values, str):
        values = frappe.parse_json(values)
    if not isinstance(values, Iterable):
        return []
    return list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))


def import_purchase_invoice_items(
    reimbursement_request_name: str,
    purchase_invoice_names: str | Iterable[str] | None = None,
    purchase_invoice_item_names: str | Iterable[str] | None = None,
) -> dict:
    """Import permitted, unpaid Purchase Invoice lines into a saved draft.

    The browser only supplies source names.  Amounts, source snapshots, and
    reservations are recalculated on the server immediately before writing.
    """
    request = frappe.get_doc("Reimbursement Request", reimbursement_request_name)
    request.check_permission("write")
    if not request.company:
        frappe.throw(_("请先填写公司并保存报销申请草稿。"))

    invoice_names = normalize_names(purchase_invoice_names)
    requested_item_names = set(normalize_names(purchase_invoice_item_names))
    if not invoice_names and requested_item_names:
        invoice_names = frappe.get_all(
            "Purchase Invoice Item",
            filters={"name": ["in", requested_item_names]},
            pluck="parent",
        )
    if not invoice_names:
        frappe.throw(_("请选择至少一张采购发票。"))

    permitted_invoices = frappe.get_list(
        "Purchase Invoice",
        filters={
            "name": ["in", invoice_names],
            "company": request.company,
            "docstatus": 1,
            "outstanding_amount": [">", 0],
        },
        fields=["name"],
        order_by="posting_date desc, name desc",
        page_length=len(invoice_names),
    )
    permitted_names = {row.name for row in permitted_invoices}
    unavailable = [name for name in invoice_names if name not in permitted_names]
    if unavailable:
        frappe.throw(_("所选采购发票不可导入、已付清、公司不一致或没有读取权限：{0}").format(", ".join(unavailable)))

    existing_sources = {
        row.source_pi_item
        for row in request.get("invoice_items")
        if row.source_pi_item
    }
    candidates = []
    for invoice_name in invoice_names:
        invoice = frappe.get_doc("Purchase Invoice", invoice_name)
        invoice.check_permission("read")
        selected_items = [
            item for item in invoice.items
            if not requested_item_names or item.name in requested_item_names
        ]
        if requested_item_names and not selected_items:
            continue
        candidates.extend(_make_candidates(invoice, selected_items, existing_sources))

    if not candidates:
        frappe.throw(_("没有可新增的采购发票明细。可能已导入当前草稿，或没有选择有效明细。"))

    _assert_sources_available(candidates, request.name)
    for candidate in candidates:
        request.append("invoice_items", candidate["row"])
        reservation = frappe.get_doc(
            {
                "doctype": "Reimbursement Source Reservation",
                "reimbursement_request": request.name,
                "source_purchase_invoice": candidate["source_pi"],
                "source_purchase_invoice_item": candidate["source_pi_item"],
                "reserved_amount": candidate["row"]["amount"],
                "status": "Draft",
            }
        )
        reservation.insert()

    request.save()
    return {
        "imported_count": len(candidates),
        "imported_amount": sum(flt(candidate["row"]["amount"]) for candidate in candidates),
    }


def release_removed_reservations(request) -> None:
    """Release draft claims that no longer have a corresponding child row."""
    source_items = {row.source_pi_item for row in request.get("invoice_items") if row.source_pi_item}
    reservations = frappe.get_all(
        "Reimbursement Source Reservation",
        filters={
            "reimbursement_request": request.name,
            "status": ["in", ACTIVE_RESERVATION_STATUSES],
        },
        pluck="name",
    )
    for name in reservations:
        reservation = frappe.get_doc("Reimbursement Source Reservation", name)
        if reservation.source_purchase_invoice_item not in source_items:
            reservation.status = "Released"
            reservation.save()


def release_all_reservations(request) -> None:
    """Release all claims when a draft reimbursement request is deleted."""
    for name in frappe.get_all(
        "Reimbursement Source Reservation",
        filters={
            "reimbursement_request": request.name,
            "status": ["in", ACTIVE_RESERVATION_STATUSES],
        },
        pluck="name",
    ):
        reservation = frappe.get_doc("Reimbursement Source Reservation", name)
        reservation.status = "Released"
        reservation.save()


def _make_candidates(invoice, items, existing_sources: set[str]) -> list[dict]:
    items = [item for item in items if item.name not in existing_sources]
    source_amounts = [_gross_amount(item) for item in items]
    if not items or not sum(source_amounts):
        return []
    total_source_amount = sum(source_amounts)
    outstanding = flt(invoice.outstanding_amount)
    remaining = outstanding
    candidates = []
    for index, item in enumerate(items):
        amount = remaining if index == len(items) - 1 else flt(source_amounts[index] / total_source_amount * outstanding, 2)
        remaining = flt(remaining - amount, 2)
        candidates.append(
            {
                "source_pi": invoice.name,
                "source_pi_item": item.name,
                "row": {
                    "item_name": item.item_name,
                    "description": item.description,
                    "qty": item.qty,
                    "uom": item.uom,
                    "rate": flt(amount / item.qty, 2) if flt(item.qty) else amount,
                    "amount": amount,
                    "invoice_no": invoice.bill_no,
                    "supplier": invoice.supplier,
                    "source_pi": invoice.name,
                    "source_pi_item": item.name,
                },
            }
        )
    return candidates


def _gross_amount(item) -> float:
    return flt(getattr(item, "custom_gross_amount", 0) or item.amount)


def _assert_sources_available(candidates: list[dict], current_request: str) -> None:
    keys = [candidate["source_pi_item"] for candidate in candidates]
    conflicts = frappe.get_all(
        "Reimbursement Source Reservation",
        filters={"active_source_key": ["in", keys]},
        fields=["source_purchase_invoice_item", "reimbursement_request"],
    )
    other_requests = sorted({row.reimbursement_request for row in conflicts if row.reimbursement_request != current_request})
    if other_requests:
        frappe.throw(_("以下来源明细已被其他报销草稿占用：{0}").format(", ".join(other_requests)))
