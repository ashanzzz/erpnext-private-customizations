"""Whitelisted reimbursement endpoints."""

from collections.abc import Iterable

import frappe

from ashan_cn_procurement.reimbursement.service import import_purchase_invoice_items


@frappe.whitelist()
def import_unpaid_purchase_invoices(
    reimbursement_request_name: str,
    purchase_invoice_names: str | Iterable[str] | None = None,
    purchase_invoice_item_names: str | Iterable[str] | None = None,
) -> dict:
    """Server-authoritative import for the Reimbursement Request form."""
    return import_purchase_invoice_items(
        reimbursement_request_name,
        purchase_invoice_names,
        purchase_invoice_item_names,
    )
