// Copyright (c) 2026, Ashan CN Procurement and contributors
// For license information, please see license.txt

frappe.query_reports["Company Compliance Overview"] = {
	"filters": [

	]
};
