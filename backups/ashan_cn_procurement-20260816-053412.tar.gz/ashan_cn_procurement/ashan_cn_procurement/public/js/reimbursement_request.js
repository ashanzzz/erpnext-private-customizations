// Copyright (c) 2026, Ashan CN Procurement and contributors
// For license information, please see license.txt

(function () {
    "use strict";

    const IMPORT_METHOD = "ashan_cn_procurement.reimbursement.api.import_unpaid_purchase_invoices";
    const PREVIEW_METHOD = "ashan_cn_procurement.reimbursement.api.preview_unpaid_purchase_invoice_items";

    frappe.ui.form.on("Reimbursement Request", {
        refresh(frm) {
            frm.page.set_secondary_action(__("获取未付款发票"), () => {
                open_unpaid_invoice_picker(frm);
            });
        },
    });

    function open_unpaid_invoice_picker(frm) {
        if (!frm.doc.company) {
            frappe.msgprint(__("请先填写公司。"));
            return;
        }

        new frappe.ui.form.MultiSelectDialog({
            doctype: "Purchase Invoice",
            target: frm,
            setters: { company: frm.doc.company },
            read_only_setters: ["company"],
            date_field: "posting_date",
            add_filters_group: 1,
            allow_child_item_selection: 1,
            child_fieldname: "items",
            child_columns: ["item_code", "item_name", "description", "qty", "uom", "amount"],
            get_query() {
                return {
                    filters: {
                        docstatus: 1,
                        outstanding_amount: [">", 0],
                        company: frm.doc.company,
                    },
                };
            },
            action(selections, args) {
                const childSelections = (args && args.filtered_children) || [];
                if (!selections.length && !childSelections.length) {
                    frappe.show_alert({ message: __("请选择采购发票或发票明细。"), indicator: "orange" }, 4);
                    return;
                }
                const isNew = frm.is_new();
                frappe.call({
                    method: isNew ? PREVIEW_METHOD : IMPORT_METHOD,
                    args: {
                        ...(isNew ? { company: frm.doc.company } : { reimbursement_request_name: frm.doc.name }),
                        purchase_invoice_names: selections,
                        purchase_invoice_item_names: childSelections,
                    },
                    freeze: true,
                    freeze_message: __("正在核验并导入来源发票明细…"),
                    callback(response) {
                        const result = response.message || {};
                        if (isNew) {
                            (result.items || []).forEach((item) => frm.add_child("invoice_items", item));
                            frm.refresh_field("invoice_items");
                        } else {
                            frm.reload_doc();
                        }
                        frappe.show_alert({
                            message: __("已导入 {0} 行，可报销合计 {1}", [
                                result.imported_count || 0,
                                format_currency(result.imported_amount || 0),
                            ]),
                            indicator: "green",
                        }, 6);
                    },
                });
            },
        });
    }
})();
