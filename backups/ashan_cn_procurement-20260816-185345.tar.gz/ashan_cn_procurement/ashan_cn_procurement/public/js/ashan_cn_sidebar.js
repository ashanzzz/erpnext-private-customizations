/* ==========================================================================
   ERPNext 16 业务扩展 - 精准层级解耦与全站统一侧边栏架构 (Strict Hierarchy & Persistent Sidebar)
   1. 一级菜单小箭头：仅折叠/展开当前一级菜单
   2. 一级菜单文字区：折叠/展开当前一级菜单 + 联动分类 Dashboard
   3. 二级菜单单据项：绝对不触发折叠/展开，纯粹 SPA 路由跳转
   4. 全站刷新持久化：即使在单据页（如 Purchase Invoice）直接按 F5 刷新，侧边栏也始终稳定保持业务扩展中文侧边栏
   ========================================================================== */

(function() {
    // 0. 路由全局重定向规则
    if (window.frappe) {
        frappe.re_route = frappe.re_route || {};
        frappe.re_route[""] = "desk/home";
        frappe.re_route["desk"] = "desk/home";
        frappe.re_route["app"] = "desk/home";
        frappe.re_route["Workspaces"] = "desk/home";
        frappe.re_route["workspaces"] = "desk/home";
    }

    // 1. 一级标题 → 对应 Workspace 映射
    const SECTION_WORKSPACE_MAP = {
        "仓库与库存": "stock-and-inventory",
        "库存": "stock-and-inventory",
        "采购协同": "procurement-management",
        "采购": "procurement-management",
        "车辆燃油": "vehicle-fuel-hub",
        "车油能耗中心": "vehicle-fuel-hub",
        "燃油管理": "vehicle-fuel-hub",
        "公司合规": "company-compliance-center",
        "企业合规中心": "company-compliance-center",
        "公司治理": "company-compliance-center",
        "财务与报销": "accounting-and-finance",
        "财务": "accounting-and-finance",
        "我的业务 (总主页)": "home",
        "我的业务 (总控主页)": "home",
        "我的业务 (总看板)": "home",
        "我的业务": "home",
        "Home": "home",
        "home": "home"
    };

    const ALL_WS_KEYS = [
        "home", "Home",
        "my business", "my-business",
        "stock and inventory", "stock-and-inventory",
        "procurement management", "procurement-management",
        "vehicle fuel hub", "vehicle-fuel-hub",
        "company compliance center", "company-compliance-center",
        "accounting and finance", "accounting-and-finance",
        "ashan cn procurement", "ashan_cn_procurement",
        "业务扩展"
    ];

    // 2. 单据页统一使用 App 维护的业务侧边栏。
    //
    // 系统 Home Sidebar 不受本 App 的 Workspace Sidebar JSON 管理。单据页若回退
    // 到 Home，会在 SPA 路由切换后渲染出缺少一级图标的旧数据。My Business 是
    // 本 App 中受版本控制的完整导航源，一级图标与二级项目均在此处统一维护。
    const BUSINESS_SIDEBAR = "My Business";
    const SYSTEM_MANAGEMENT_SECTION = "系统管理";
    const SYSTEM_MANAGEMENT_ROUTES = [
        "/desk/client-script",
        "/desk/customize-form",
        "/desk/server-script",
        "/desk/system-settings"
    ];

    function get_system_manager_status() {
        if (!window.frappe) return null;
        if (frappe.boot && Object.prototype.hasOwnProperty.call(frappe.boot, "ashan_is_system_manager")) {
            return Boolean(frappe.boot.ashan_is_system_manager);
        }
        if (frappe.boot && frappe.boot.user && Array.isArray(frappe.boot.user.roles)) {
            return frappe.boot.user.roles.includes("System Manager");
        }
        if (Array.isArray(frappe.user_roles)) {
            return frappe.user_roles.includes("System Manager");
        }
        if (frappe.user && typeof frappe.user.has_role === "function") {
            return Boolean(frappe.user.has_role("System Manager"));
        }
        return null;
    }

    // Workspace Sidebar Item has no native role field in Frappe v16. Keep the
    // business navigation clean for ordinary users; actual access remains
    // protected by the standard DocType and System Settings permissions.
    function restrict_system_management_section() {
        if (get_system_manager_status() !== false) return;
        const $sidebar = $(".body-sidebar");
        if (!$sidebar.length) return;

        $sidebar.find("a").filter(function() {
            const href = $(this).attr("href") || "";
            return SYSTEM_MANAGEMENT_ROUTES.some((route) => href === route || href.startsWith(`${route}?`));
        }).closest(".sidebar-child-item").remove();

        $sidebar.find(".section-item").filter(function() {
            const $section = $(this);
            const title = ($section.attr("item-name") || $section.attr("title") || "").trim();
            return title === SYSTEM_MANAGEMENT_SECTION
                || $section.find(".sidebar-item-label").first().text().trim() === SYSTEM_MANAGEMENT_SECTION;
        }).each(function() {
            const $section = $(this);
            // Support both v16 sidebar layouts: children nested in the section
            // and children following it as sibling sidebar items.
            $section.nextUntil(".section-item").filter(".sidebar-child-item").remove();
            $section.remove();
        });
    }

    function schedule_system_management_visibility(retries = 20) {
        const status = get_system_manager_status();
        // Temporary diagnostic marker for browser acceptance. Removed once the
        // v16 boot timing source is verified.
        if (document.body) {
            document.body.setAttribute("data-ashan-system-manager-status", String(status));
        }
        if (status === true) return;
        if (status === false || retries <= 0) {
            restrict_system_management_section();
            return;
        }
        // app_include_js can run before Frappe finishes hydrating boot data.
        // Wait for the authoritative server-provided role marker instead of
        // mistaking that transient state for an ordinary user.
        window.setTimeout(() => schedule_system_management_visibility(retries - 1), 150);
    }

    function patch_sidebar_resolver() {
        if (!window.frappe || !frappe.ui || !frappe.ui.Sidebar) return false;
        const Sidebar = frappe.ui.Sidebar;
        if (Sidebar._ashan_resolved_patched) return true;

        const orig_resolve_sidebar = Sidebar.prototype.resolve_sidebar;
        Sidebar.prototype.resolve_sidebar = function(doctype, module) {
            // 当处于采购、库存、财务等业务单据或标准模块时，统一解析为 App 维护的
            // 业务侧边栏。这样从一级看板进入任意二级单据后，不会切换到系统 Home。
            const mod_lower = (module || "").toLowerCase();
            if (!module || mod_lower === "setup" || mod_lower === "buying" || mod_lower === "stock" || mod_lower === "accounts" || mod_lower === "hr" || mod_lower === "ashan_cn_procurement" || mod_lower === "ashan cn procurement") {
                return BUSINESS_SIDEBAR;
            }
            const res = orig_resolve_sidebar ? orig_resolve_sidebar.apply(this, arguments) : null;
            return res || BUSINESS_SIDEBAR;
        };

        const orig_choose_app_name = Sidebar.prototype.choose_app_name;
        Sidebar.prototype.choose_app_name = function() {
            if (orig_choose_app_name) orig_choose_app_name.apply(this, arguments);
            const title_lower = (this.sidebar_title || "").toLowerCase();
            if (title_lower === "home" || title_lower === "my business" || ALL_WS_KEYS.includes(title_lower)) {
                this.header_subtitle = "业务扩展";
                if (this.sidebar_header && this.sidebar_header.find) {
                    this.sidebar_header.find(".sidebar-header-subtitle").text("业务扩展");
                }
            }
        };

        Sidebar._ashan_resolved_patched = true;
        return true;
    }

    // 3. 深度重写 Frappe 原生 TypeSectionBreak 原型方法
    function patch_native_section_break() {
        if (!window.frappe || !frappe.ui || !frappe.ui.sidebar_item || !frappe.ui.sidebar_item.TypeSectionBreak) {
            return false;
        }

        const TypeSectionBreak = frappe.ui.sidebar_item.TypeSectionBreak;
        if (TypeSectionBreak._ashan_strict_patched) return true;

        // 丝滑动画切换 toggle()
        // Frappe 内部的 open()/close() 会在 SPA 路由切换与侧栏尺寸变化时调用
        // toggle()，这类同步不应播放动画；一级文字和箭头的用户点击会显式传入
        // true，仍保留 180ms 的展开/收起反馈。
        TypeSectionBreak.prototype.toggle = function(animate = false) {
            const $nested = $(this.$nested_items);
            if (!$nested.length) return;

            $nested.removeClass("hidden");

            if (this.collapsed) {
                if (this.$drop_icon) {
                    this.$drop_icon.attr("data-state", "closed").find("use").attr("href", "#icon-chevron-right");
                }
                $(this.wrapper).attr("data-state", "closed");
                if (animate) {
                    $nested.stop(true, true).slideUp(180);
                } else {
                    $nested.hide();
                }
            } else {
                if (this.$drop_icon) {
                    this.$drop_icon.attr("data-state", "opened").find("use").attr("href", "#icon-chevron-down");
                }
                $(this.wrapper).attr("data-state", "opened");
                if (animate) {
                    $nested.stop(true, true).slideDown(180);
                } else {
                    $nested.show();
                }
            }
        };

        // 状态持久化
        TypeSectionBreak.prototype.save_section_break_state = function() {
            try {
                let state = JSON.parse(localStorage.getItem("section-breaks-state") || "{}");
                const title = (this.wrapper.attr("item-name") || this.wrapper.attr("title") || "").trim();
                if (title) {
                    ALL_WS_KEYS.forEach(k => {
                        if (!state[k]) state[k] = {};
                        state[k][title] = this.collapsed;
                    });
                    this.section_breaks_state = state;
                    localStorage.setItem("section-breaks-state", JSON.stringify(state));
                }
            } catch(e) {}
        };

        // 严格层级解耦：只给一级标题的元素绑定事件，绝对不污染二级子菜单
        TypeSectionBreak.prototype.setup_event_listner = function() {
            const me = this;
            const $l1_standard_item = this.wrapper.children(".standard-sidebar-item");
            if (!$l1_standard_item.length) return;

            $l1_standard_item.off("click");

            // [1] 一级右侧小箭头按钮 -> 仅执行手风琴折叠/展开
            $l1_standard_item.find(".sidebar-item-control, .drop-icon").off("click").on("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (e.stopImmediatePropagation) e.stopImmediatePropagation();
                me.collapsed = !me.collapsed;
                me.toggle(true);
                me.save_section_break_state();
            });

            // [2] 一级左侧文字与图标 -> 仅在一级标题点击时触发折叠/展开 + 联动看板
            $l1_standard_item.find(".sidebar-item-label, .sidebar-item-icon, .item-anchor").off("click").on("click", function(e) {
                if ($(e.target).closest(".sidebar-item-control, .drop-icon").length) return;

                e.preventDefault();
                e.stopPropagation();

                // 丝滑展开/折叠切换当前一级菜单
                me.collapsed = !me.collapsed;
                me.toggle(true);
                me.save_section_break_state();

                // 联动跳转至对应分类 Dashboard
                const title = (me.wrapper.attr("item-name") || me.wrapper.attr("title") || "").trim();
                const targetWs = SECTION_WORKSPACE_MAP[title];
                if (targetWs) {
                    try {
                        const currentRoute = (frappe.router && frappe.router.current_route) ? (frappe.get_route_str() || "") : "";
                        if (!currentRoute.includes(targetWs)) {
                            frappe.set_route("desk", targetWs);
                        }
                    } catch(err) {}
                }
            });
        };

        TypeSectionBreak._ashan_strict_patched = true;
        return true;
    }

    // 4. 注入样式
    function inject_styles() {
        if ($("#ashan-strict-style").length) return;
        const styleHtml = `
        <style id="ashan-strict-style">
            .body-sidebar .section-item > .standard-sidebar-item .item-anchor {
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                border-radius: var(--border-radius, 6px);
                transition: background-color 0.15s ease;
                padding: 4px 8px !important;
                user-select: none;
            }
            .body-sidebar .section-item > .standard-sidebar-item .item-anchor:hover {
                background-color: rgba(0, 0, 0, 0.05);
            }
            .body-sidebar .section-item > .standard-sidebar-item .sidebar-item-label {
                font-weight: 700 !important;
                font-size: 13.5px !important;
                color: var(--text-color, #1f272e) !important;
                flex: 1 !important;
                cursor: pointer !important;
                transition: color 0.15s ease;
            }
            .body-sidebar .section-item > .standard-sidebar-item .sidebar-item-label:hover {
                color: var(--primary-color, #2f54eb) !important;
            }
            .body-sidebar .section-item > .standard-sidebar-item .sidebar-item-control {
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                margin-left: auto !important;
                z-index: 10;
            }
            .body-sidebar .section-item > .standard-sidebar-item .sidebar-item-control .drop-icon {
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                width: 28px !important;
                height: 28px !important;
                border-radius: 4px !important;
                cursor: pointer !important;
                transition: background-color 0.15s ease, transform 0.15s ease;
                pointer-events: auto !important;
            }
            .body-sidebar .section-item > .standard-sidebar-item .sidebar-item-control .drop-icon:hover {
                background-color: rgba(0, 0, 0, 0.12) !important;
            }
            .body-sidebar .sidebar-child-item .sidebar-item-icon {
                display: none !important;
            }
            .body-sidebar .sidebar-child-item .standard-sidebar-item .item-anchor {
                padding-left: 24px !important;
                font-size: 13px !important;
                font-weight: 400 !important;
                cursor: pointer !important;
            }
        </style>
        `;
        $("head").append(styleHtml);
    }

    // 5. 初始化挂载
    function init() {
        inject_styles();
        patch_sidebar_resolver();
        patch_native_section_break();
        schedule_system_management_visibility();

        $(document).on("sidebar_setup app_ready route-change page-change", function() {
            inject_styles();
            patch_sidebar_resolver();
            patch_native_section_break();
            schedule_system_management_visibility();
        });
    }

    init();
    $(document).ready(init);
    $(document).on("app_ready", init);
})();
