"""Remove retired custom specification fields.

The project now uses the native ``description`` field as its sole item
explanation. This patch intentionally removes the obsolete field and its
stored values; it does not copy that value into ``description``.
"""

import frappe


TARGET_DOCTYPES = (
    "Item",
    "Purchase Receipt Item",
    "Purchase Invoice Item",
)


def execute():
    for doctype in TARGET_DOCTYPES:
        custom_field_name = f"{doctype}-custom_guige_xinghao"
        if frappe.db.exists("Custom Field", custom_field_name):
            frappe.delete_doc("Custom Field", custom_field_name, force=True)
