"""Application migration patches."""
