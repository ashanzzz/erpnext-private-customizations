"""Small, session-scoped APIs for the ashan business sidebar."""

import frappe


@frappe.whitelist()
def get_system_management_visibility():
	"""Return whether the current Desk session may see system-management links."""
	return {
		"is_system_manager": (
			frappe.session.user != "Guest"
			and "System Manager" in frappe.get_roles(frappe.session.user)
		)
	}
