// Copyright (c) 2026, Ashan CN Procurement and contributors
// For license information, please see license.txt

(function () {
    "use strict";

    const IMPORT_METHOD = "ashan_cn_procurement.reimbursement.api.import_unpaid_purchase_invoices";
    const PREVIEW_METHOD = "ashan_cn_procurement.reimbursement.api.preview_unpaid_purchase_invoice_items";
    const FILTER_OPTIONS_METHOD = "ashan_cn_procurement.reimbursement.api.get_unpaid_purchase_invoice_filter_options";
    const SEARCH_METHOD = "ashan_cn_procurement.reimbursement.api.search_unpaid_purchase_invoices";

    frappe.ui.form.on("Reimbursement Request", {
        refresh(frm) {
            add_unpaid_invoice_action(frm);
        },
    });

    // app_include_js may finish loading after a directly-opened Form has
    // already emitted refresh. Reapply on route changes so the action does not
    // disappear on a new reimbursement request or after Desk navigation.
    frappe.router.on("change", () => {
        window.setTimeout(() => add_unpaid_invoice_action(window.cur_frm), 150);
    });

    function add_unpaid_invoice_action(frm) {
        if (!frm || frm.doctype !== "Reimbursement Request" || !frm.page) {
            return;
        }
        frm.page.set_secondary_action(__("获取未付款发票"), () => {
            open_unpaid_invoice_filter(frm);
        });
    }

    function open_unpaid_invoice_filter(frm) {
        if (!frm.doc.company) {
            frappe.msgprint(__("请先填写公司。"));
            return;
        }

        frappe.call({
            method: FILTER_OPTIONS_METHOD,
            args: { company: frm.doc.company },
            callback(response) {
                const invoiceTypes = (response.message && response.message.invoice_types) || [];
                show_unpaid_invoice_filter(frm, invoiceTypes);
            },
        });
    }

    function show_unpaid_invoice_filter(frm, invoiceTypes) {
        const dialog = new frappe.ui.Dialog({
            title: __("筛选未付款采购发票"),
            fields: [
                { fieldname: "bill_no", label: __("发票号"), fieldtype: "Data" },
                { fieldname: "bill_date_from", label: __("发票日期（起）"), fieldtype: "Date" },
                { fieldname: "bill_date_to", label: __("发票日期（止）"), fieldtype: "Date" },
                {
                    fieldname: "custom_invoice_type",
                    label: __("发票类型"),
                    fieldtype: "Select",
                    options: ["", ...invoiceTypes].join("\n"),
                },
                { fieldname: "supplier", label: __("供应商"), fieldtype: "Link", options: "Supplier" },
                { fieldname: "item_name", label: __("物料名"), fieldtype: "Data" },
                { fieldname: "min_outstanding_amount", label: __("待付金额（最小）"), fieldtype: "Currency" },
                { fieldname: "max_outstanding_amount", label: __("待付金额（最大）"), fieldtype: "Currency" },
            ],
            primary_action_label: __("选择发票"),
            primary_action(values) {
                dialog.hide();
                open_unpaid_invoice_picker(frm, values);
            },
        });
        dialog.show();
    }

    function open_unpaid_invoice_picker(frm, filters) {

        new frappe.ui.form.MultiSelectDialog({
            doctype: "Purchase Invoice",
            target: frm,
            setters: { company: frm.doc.company },
            read_only_setters: ["company"],
            date_field: "bill_date",
            allow_child_item_selection: 1,
            child_fieldname: "items",
            child_columns: ["item_code", "item_name", "description", "qty", "uom", "amount"],
            get_query() {
                return {
                    query: SEARCH_METHOD,
                    filters: { company: frm.doc.company, ...filters },
                };
            },
            action(selections, args) {
                const childSelections = (args && args.filtered_children) || [];
                if (!selections.length && !childSelections.length) {
                    frappe.show_alert({ message: __("请选择采购发票或发票明细。"), indicator: "orange" }, 4);
                    return;
                }
                const isNew = frm.is_new();
                frappe.call({
                    method: isNew ? PREVIEW_METHOD : IMPORT_METHOD,
                    args: {
                        ...(isNew ? { company: frm.doc.company } : { reimbursement_request_name: frm.doc.name }),
                        purchase_invoice_names: selections,
                        purchase_invoice_item_names: childSelections,
                    },
                    freeze: true,
                    freeze_message: __("正在核验并导入来源发票明细…"),
                    callback(response) {
                        const result = response.message || {};
                        if (isNew) {
                            (result.items || []).forEach((item) => frm.add_child("invoice_items", item));
                            frm.refresh_field("invoice_items");
                        } else {
                            frm.reload_doc();
                        }
                        frappe.show_alert({
                            message: __("已导入 {0} 行，可报销合计 {1}", [
                                result.imported_count || 0,
                                format_currency(result.imported_amount || 0),
                            ]),
                            indicator: "green",
                        }, 6);
                    },
                });
            },
        });
    }
})();
